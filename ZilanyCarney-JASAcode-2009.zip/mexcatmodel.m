clear all;
mex -v catmodel_IHC.c complex.c  
clear all;
mex -v catmodel_Synapse.c complex.c 